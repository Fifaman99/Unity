using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaerMoventNew : MonoBehaviour
{
    public float Speed;
    public bool isGrounded;

    private Vector3 _direction;
    private Rigidbody rb;

    void Start()
    {
        this.rb = this.GetComponent<Rigidbody>();
    }


    void Update()
    {
        _direction.x = Input.GetAxis("Horizontal");
        _direction.z = Input.GetAxis("Vertical");
        Debug.Log(_direction);

        if (Input.GetKeyDown(KeyCode.Space))
            this.Jump();
    }

    private void Jump()
    {
        if (this.isGrounded)
            this.rb.AddForce(this.jumpDirection * this.jumpPower, ForceMode.Impulse);
    }

    private void OnCollisionEnter(Collision other)
    {
        var ground = other.gameObject.GetComponentInParent<Ground>();
        if (ground)
            this.isGrounded = true;
    }

    private void OnCollisionExit(Collision other)
    {
        var ground = other.gameObject.GetComponentInParentgs<Ground>();
        if (ground)
            this.isGrounded = false;
    }


    void FixedUpdate()
    {
        transform.position = transform.position + _direction * Time.fixedDeltaTime * Speed;
    }
}
